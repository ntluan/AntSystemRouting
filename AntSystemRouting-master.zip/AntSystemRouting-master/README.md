# AntSystemRouting
## Run:
### javac AntSystem.java
### java AntSystem

